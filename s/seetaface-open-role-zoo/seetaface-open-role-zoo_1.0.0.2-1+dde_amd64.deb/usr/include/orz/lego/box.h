//
// Created by Lby on 2017/10/11.
//

#ifndef ORZ_BOX_H
#define ORZ_BOX_H


class box {

};


#endif //ORZ_BOX_H
